# Dron - Fabric 1.21.1

- Entidad `dronmod:dron` (huevo generador en la pestana de huevos; tambien `/summon dronmod:dron`). No aparece solo.
- Zumbido de dron en bucle cuando esta cerca; las helices giran.
- Detecta jugadores en supervivencia/aventura (24 bloques), se acerca a ~5 bloques y flota.
- A menos de ~8.5 bloques y con linea de vision te agarra: camara bloqueada mirandolo.
- Sale una tecla ESPACIO animada y una barra: pulsa ESPACIO repetidamente para llenarla (baja sola si paras).
- Al liberarte el dron huye ~20 s y luego vuelve.

Compilar: ver `.github/workflows/build.yml` (GitHub Actions) o `gradle build` con JDK 21. Requiere Fabric API 1.21.1.

## Ataque y efectos
- Cada ~2.5 s (3.5 s si te tiene agarrado) dispara una bola de fuego morada (3 de dano, te prende fuego y debilidad).
- Al chocar deja una zona de fuego morado ~7 s que quema y da debilidad.
- Mientras te agarra: bordes de pantalla rojos difuminados y sonido de estatica.
- Al morir explota como un creeper normal (respeta mobGriefing).

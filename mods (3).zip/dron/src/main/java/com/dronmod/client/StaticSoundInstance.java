package com.dronmod.client;

import com.dronmod.ModSounds;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;

/** Estatica en bucle mientras el dron te tiene agarrado (se oye "dentro de la cabeza", sin posicion). */
public class StaticSoundInstance extends MovingSoundInstance {
    public StaticSoundInstance() {
        super(ModSounds.STATIC_LOOP, SoundCategory.MASTER, SoundInstance.createRandom());
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 0.8f;
        this.pitch = 1.0f;
        this.relative = true;
        this.attenuationType = SoundInstance.AttenuationType.NONE;
    }

    @Override
    public void tick() {
        if (!DroneClientState.active) {
            setDone();
        }
    }
}

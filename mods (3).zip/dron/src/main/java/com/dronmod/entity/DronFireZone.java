package com.dronmod.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.AreaEffectCloudEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

import java.util.List;

/**
 * Zona de fuego morado: quema y da debilidad a los seres vivos dentro.
 * Es una nube de area vanilla (el cliente la dibuja normal); la logica es solo del servidor.
 */
public class DronFireZone extends AreaEffectCloudEntity {
    public DronFireZone(World world, double x, double y, double z) {
        super(world, x, y, z);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (getWorld() instanceof ServerWorld sw && age % 4 == 0) {
            sw.spawnParticles(ParticleTypes.WITCH, getX(), getY() + 0.2, getZ(), 4, getRadius() * 0.5, 0.2, getRadius() * 0.5, 0.01);
        }
        if (age % 10 != 0) return;
        double r = getRadius();
        List<LivingEntity> list = getWorld().getEntitiesByClass(LivingEntity.class,
                getBoundingBox().expand(0.0, 1.0, 0.0), e -> e.isAlive() && !(e instanceof DroneEntity));
        for (LivingEntity e : list) {
            double dx = e.getX() - getX(), dz = e.getZ() - getZ();
            if (dx * dx + dz * dz > r * r) continue;
            e.setOnFireFor(3);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 0));
        }
    }
}

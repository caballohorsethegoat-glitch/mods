package com.dronmod.entity;

import com.dronmod.DronMod;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.joml.Vector3f;

/**
 * Bola de fuego morada: al golpear a alguien lo quema y le da debilidad;
 * al chocar deja una zona de fuego morado (DronFireZone) que da debilidad.
 */
public class DronFireballEntity extends ThrownItemEntity {
    public static final float DAMAGE = 3.0f;
    public static final DustParticleEffect PURPLE = new DustParticleEffect(new Vector3f(0.55f, 0.1f, 0.9f), 1.4f);

    public DronFireballEntity(EntityType<? extends DronFireballEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
    }

    public DronFireballEntity(World world, LivingEntity owner) {
        super(DronMod.DRON_FIREBALL, owner, world);
        this.setNoGravity(true);
    }

    @Override
    protected Item getDefaultItem() {
        return DronMod.PURPLE_FIRE_CHARGE;
    }

    @Override
    protected boolean canHit(Entity entity) {
        return !(entity instanceof DroneEntity) && super.canHit(entity);
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient) {
            if (age > 200) {
                discard();
                return;
            }
            if (getWorld() instanceof ServerWorld sw) {
                sw.spawnParticles(PURPLE, getX(), getY(), getZ(), 2, 0.05, 0.05, 0.05, 0.0);
            }
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        super.onEntityHit(hit);
        if (getWorld().isClient) return;
        Entity e = hit.getEntity();
        if (e instanceof LivingEntity le) {
            le.damage(getWorld().getDamageSources().thrown(this, getOwner()), DAMAGE);
            le.setOnFireFor(6);
            le.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 0));
        }
    }

    @Override
    protected void onCollision(HitResult hit) {
        super.onCollision(hit);
        if (!getWorld().isClient) {
            DronFireZone zone = new DronFireZone(getWorld(), hit.getPos().x, hit.getPos().y, hit.getPos().z);
            zone.setRadius(2.2f);
            zone.setDuration(140);
            zone.setParticleType(PURPLE);
            getWorld().spawnEntity(zone);
            getWorld().playSound(null, hit.getPos().x, hit.getPos().y, hit.getPos().z,
                    SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.HOSTILE, 1.0f, 0.6f);
            discard();
        }
    }
}

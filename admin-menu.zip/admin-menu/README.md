# Admin Menu - Fabric 1.21.1

Menu de administracion que se abre con la tecla **.** (cambiable en Opciones > Controles). Solo lo abren los **OP** (nivel 2+).

- Pestana **Comandos**: agrega un comando (con nombre) y queda como boton **Ejecutar** de un clic. Se ejecuta con tus permisos, como si lo escribieras en el chat.
- Pestana **Objetos**: agrega un objeto/bloque (id + cantidad, o el boton **Mano** para copiar el de tu mano) y queda como boton **Dar**.
- Boton **X** borra la entrada. Rueda del mouse o `<` `>` para cambiar de pagina. **Enter** en un campo = Añadir.
- La lista es compartida por todos los OP del servidor y se guarda en `config/adminmenu.json`.
- Toda accion se valida en el servidor: un jugador sin OP no puede ejecutar nada aunque modifique su cliente.

Nota: en un mundo de un jugador, tu personaje debe ser OP (trucos activados) para poder abrirlo.
Requiere Fabric API 1.21.1.

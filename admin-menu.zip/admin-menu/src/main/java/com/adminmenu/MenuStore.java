package com.adminmenu;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Lista de entradas guardada en config/adminmenu.json (compartida por todos los admins del servidor). */
public class MenuStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<MenuEntry> ENTRIES = new CopyOnWriteArrayList<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("adminmenu.json");
    }

    public static synchronized void load() {
        ENTRIES.clear();
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            MenuEntry[] arr = GSON.fromJson(r, MenuEntry[].class);
            if (arr != null) ENTRIES.addAll(Arrays.asList(arr));
        } catch (Exception e) {
            AdminMenuMod.LOGGER.error("No se pudo leer adminmenu.json", e);
        }
    }

    public static synchronized void save() {
        try {
            Files.writeString(file(), GSON.toJson(ENTRIES), StandardCharsets.UTF_8);
        } catch (Exception e) {
            AdminMenuMod.LOGGER.error("No se pudo guardar adminmenu.json", e);
        }
    }

    public static List<MenuEntry> all() {
        return new ArrayList<>(ENTRIES);
    }

    public static synchronized void add(MenuEntry e) {
        ENTRIES.add(e);
        save();
    }

    public static synchronized boolean remove(String id) {
        boolean removed = ENTRIES.removeIf(e -> e.id.equals(id));
        if (removed) save();
        return removed;
    }

    public static MenuEntry find(String id) {
        for (MenuEntry e : ENTRIES) if (e.id.equals(id)) return e;
        return null;
    }
}

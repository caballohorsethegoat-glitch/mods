package com.adminmenu.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Admin -> servidor: agrega una entrada (comando u objeto). */
public record AddPayload(String type, String label, String value, int count) implements CustomPayload {
    public static final CustomPayload.Id<AddPayload> ID = new CustomPayload.Id<>(Identifier.of("adminmenu", "add"));
    public static final PacketCodec<RegistryByteBuf, AddPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, AddPayload::type,
            PacketCodecs.STRING, AddPayload::label,
            PacketCodecs.STRING, AddPayload::value,
            PacketCodecs.VAR_INT, AddPayload::count,
            AddPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

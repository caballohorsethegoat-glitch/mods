package com.adminmenu.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Admin -> servidor: acciones sobre una entrada (por id). */
public record RemovePayload(String id) implements CustomPayload {
    public static final CustomPayload.Id<RemovePayload> ID = new CustomPayload.Id<>(Identifier.of("adminmenu", "remove"));
    public static final PacketCodec<RegistryByteBuf, RemovePayload> CODEC =
            PacketCodecs.STRING.xmap(RemovePayload::new, RemovePayload::id).cast();

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

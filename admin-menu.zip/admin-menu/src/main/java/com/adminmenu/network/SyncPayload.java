package com.adminmenu.network;

import com.adminmenu.MenuEntry;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** Servidor -> admin: lista completa de entradas. */
public record SyncPayload(List<MenuEntry> entries) implements CustomPayload {
    public static final CustomPayload.Id<SyncPayload> ID = new CustomPayload.Id<>(Identifier.of("adminmenu", "sync"));
    public static final PacketCodec<RegistryByteBuf, SyncPayload> CODEC = new PacketCodec<RegistryByteBuf, SyncPayload>() {
        @Override
        public SyncPayload decode(RegistryByteBuf buf) {
            int n = buf.readVarInt();
            List<MenuEntry> list = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                list.add(new MenuEntry(buf.readString(), buf.readString(), buf.readString(), buf.readString(), buf.readVarInt()));
            }
            return new SyncPayload(list);
        }

        @Override
        public void encode(RegistryByteBuf buf, SyncPayload p) {
            buf.writeVarInt(p.entries().size());
            for (MenuEntry e : p.entries()) {
                buf.writeString(e.id);
                buf.writeString(e.type);
                buf.writeString(e.label);
                buf.writeString(e.value);
                buf.writeVarInt(e.count);
            }
        }
    };

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

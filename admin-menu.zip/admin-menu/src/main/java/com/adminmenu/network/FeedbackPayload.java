package com.adminmenu.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Servidor -> admin: mensaje corto para mostrar en el menu. */
public record FeedbackPayload(String text) implements CustomPayload {
    public static final CustomPayload.Id<FeedbackPayload> ID = new CustomPayload.Id<>(Identifier.of("adminmenu", "feedback"));
    public static final PacketCodec<RegistryByteBuf, FeedbackPayload> CODEC =
            PacketCodecs.STRING.xmap(FeedbackPayload::new, FeedbackPayload::text).cast();

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

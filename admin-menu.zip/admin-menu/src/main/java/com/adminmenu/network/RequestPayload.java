package com.adminmenu.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Admin -> servidor: pide la lista de entradas. */
public record RequestPayload() implements CustomPayload {
    public static final CustomPayload.Id<RequestPayload> ID = new CustomPayload.Id<>(Identifier.of("adminmenu", "request"));
    public static final PacketCodec<RegistryByteBuf, RequestPayload> CODEC = PacketCodec.unit(new RequestPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

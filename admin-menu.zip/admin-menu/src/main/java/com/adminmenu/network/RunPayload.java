package com.adminmenu.network;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Admin -> servidor: acciones sobre una entrada (por id). */
public record RunPayload(String id) implements CustomPayload {
    public static final CustomPayload.Id<RunPayload> ID = new CustomPayload.Id<>(Identifier.of("adminmenu", "run"));
    public static final PacketCodec<RegistryByteBuf, RunPayload> CODEC =
            PacketCodecs.STRING.xmap(RunPayload::new, RunPayload::id).cast();

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}

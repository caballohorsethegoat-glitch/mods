package com.adminmenu;

/** Una entrada del menu: un comando o un objeto. type = "command" | "item". */
public class MenuEntry {
    public String id;
    public String type;
    public String label;
    public String value;   // comando (sin "/") o id del objeto (minecraft:diamond_sword)
    public int count;      // cantidad (solo objetos)

    public MenuEntry() {}

    public MenuEntry(String id, String type, String label, String value, int count) {
        this.id = id;
        this.type = type;
        this.label = label;
        this.value = value;
        this.count = count;
    }
}

package com.adminmenu;

import com.adminmenu.network.AddPayload;
import com.adminmenu.network.FeedbackPayload;
import com.adminmenu.network.RemovePayload;
import com.adminmenu.network.RequestPayload;
import com.adminmenu.network.RunPayload;
import com.adminmenu.network.SyncPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * Menu de administracion. Todas las acciones se validan en el servidor: solo jugadores
 * con permiso de OP (nivel 2 o mas) pueden ver la lista, agregar, borrar o ejecutar entradas.
 */
public class AdminMenuMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("adminmenu");
    public static final int OP_LEVEL = 2;

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(FeedbackPayload.ID, FeedbackPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestPayload.ID, RequestPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(AddPayload.ID, AddPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RemovePayload.ID, RemovePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RunPayload.ID, RunPayload.CODEC);

        ServerLifecycleEvents.SERVER_STARTING.register(server -> MenuStore.load());

        // Pedir la lista
        ServerPlayNetworking.registerGlobalReceiver(RequestPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (!isOp(p)) return;
            ServerPlayNetworking.send(p, new SyncPayload(MenuStore.all()));
        });

        // Agregar comando u objeto
        ServerPlayNetworking.registerGlobalReceiver(AddPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (!isOp(p)) return;

            String type = "item".equals(payload.type()) ? "item" : "command";
            String value = payload.value() == null ? "" : payload.value().trim();
            String label = payload.label() == null ? "" : payload.label().trim();
            if (value.isEmpty() || value.length() > 256) {
                feedback(p, "Valor vacío o demasiado largo");
                return;
            }
            int count = 1;
            if (type.equals("command")) {
                if (value.startsWith("/")) value = value.substring(1).trim();
                if (value.isEmpty()) {
                    feedback(p, "Escribe un comando");
                    return;
                }
            } else {
                Identifier id = Identifier.tryParse(value);
                if (id == null || !Registries.ITEM.containsId(id) || Registries.ITEM.get(id) == Items.AIR) {
                    feedback(p, "Ese objeto no existe: " + value);
                    return;
                }
                Item item = Registries.ITEM.get(id);
                value = id.toString();
                count = Math.max(1, Math.min(payload.count(), item.getMaxCount()));
            }
            if (label.isEmpty()) label = value;
            if (label.length() > 40) label = label.substring(0, 40);

            MenuStore.add(new MenuEntry(UUID.randomUUID().toString(), type, label, value, count));
            feedback(p, "Añadido: " + label);
            broadcast(context.server());
        });

        // Borrar
        ServerPlayNetworking.registerGlobalReceiver(RemovePayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (!isOp(p)) return;
            if (MenuStore.remove(payload.id())) {
                feedback(p, "Entrada eliminada");
                broadcast(context.server());
            }
        });

        // Ejecutar / dar
        ServerPlayNetworking.registerGlobalReceiver(RunPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (!isOp(p)) return;
            MenuEntry e = MenuStore.find(payload.id());
            if (e == null) {
                feedback(p, "La entrada ya no existe");
                return;
            }
            if ("command".equals(e.type)) {
                // se ejecuta como si el admin lo escribiera en el chat (con sus permisos)
                context.server().getCommandManager().executeWithPrefix(p.getCommandSource(), e.value);
            } else {
                Identifier id = Identifier.tryParse(e.value);
                if (id == null || !Registries.ITEM.containsId(id)) {
                    feedback(p, "Objeto inválido: " + e.value);
                    return;
                }
                Item item = Registries.ITEM.get(id);
                ItemStack stack = new ItemStack(item, Math.max(1, Math.min(e.count, item.getMaxCount())));
                p.getInventory().offerOrDrop(stack);
                feedback(p, "Recibiste " + stack.getCount() + "x " + e.label);
            }
        });
    }

    public static boolean isOp(ServerPlayerEntity p) {
        return p.hasPermissionLevel(OP_LEVEL);
    }

    private static void feedback(ServerPlayerEntity p, String msg) {
        ServerPlayNetworking.send(p, new FeedbackPayload(msg));
    }

    private static void broadcast(MinecraftServer server) {
        SyncPayload payload = new SyncPayload(MenuStore.all());
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
            if (isOp(sp)) ServerPlayNetworking.send(sp, payload);
        }
    }
}

package com.adminmenu.client;

import com.adminmenu.MenuEntry;

import java.util.ArrayList;
import java.util.List;

public class ClientState {
    public static List<MenuEntry> entries = new ArrayList<>();
    public static String feedback = "";
}

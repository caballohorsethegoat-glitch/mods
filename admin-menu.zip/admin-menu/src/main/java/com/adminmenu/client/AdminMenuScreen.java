package com.adminmenu.client;

import com.adminmenu.MenuEntry;
import com.adminmenu.network.AddPayload;
import com.adminmenu.network.RemovePayload;
import com.adminmenu.network.RunPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Menu de admin: pestanas Comandos / Objetos, boton de un clic por entrada y formulario para agregar. */
public class AdminMenuScreen extends Screen {
    private static final int ROWS = 5;
    private static final int ROW_H = 22;
    private static final int PANEL_H = 236;

    // se conservan al refrescar la pantalla
    private static int tab = 0;                // 0 = comandos, 1 = objetos
    private static String labelText = "";
    private static String valueText = "";
    private static String countText = "1";
    private static boolean closeOnRun = true;

    private int page = 0;
    private int left, top;
    private final List<MenuEntry> shown = new ArrayList<>();
    private TextFieldWidget labelField, valueField, countField;

    public AdminMenuScreen() {
        super(Text.literal("Menú de Admin"));
    }

    public void refresh() {
        clearAndInit();
    }

    @Override
    public boolean shouldPause() {
        return false; // el juego sigue corriendo para que los comandos se ejecuten al instante
    }

    @Override
    protected void init() {
        left = this.width / 2 - 160;
        top = Math.max(6, (this.height - PANEL_H) / 2);

        shown.clear();
        for (MenuEntry e : ClientState.entries) {
            if ((tab == 0) == "command".equals(e.type)) shown.add(e);
        }
        int pages = Math.max(1, (shown.size() + ROWS - 1) / ROWS);
        page = MathHelper.clamp(page, 0, pages - 1);

        // ---- pestanas
        addDrawableChild(ButtonWidget.builder(Text.literal(tab == 0 ? "» Comandos «" : "Comandos"), b -> {
            tab = 0; page = 0; clearAndInit();
        }).dimensions(left, top + 16, 158, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(tab == 1 ? "» Objetos «" : "Objetos"), b -> {
            tab = 1; page = 0; clearAndInit();
        }).dimensions(left + 162, top + 16, 158, 20).build());

        // ---- filas (boton de accion + borrar)
        int start = page * ROWS;
        for (int i = 0; i < ROWS && start + i < shown.size(); i++) {
            MenuEntry e = shown.get(start + i);
            int y = top + 42 + i * ROW_H;
            addDrawableChild(ButtonWidget.builder(Text.literal(tab == 0 ? "Ejecutar" : "Dar"), b -> run(e))
                    .dimensions(left + 236, y, 56, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("X"), b -> remove(e))
                    .dimensions(left + 296, y, 24, 20).build());
        }

        // ---- paginacion
        int py = top + 42 + ROWS * ROW_H + 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> { page--; clearAndInit(); })
                .dimensions(left, py, 24, 20).build()).active = page > 0;
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { page++; clearAndInit(); })
                .dimensions(left + 296, py, 24, 20).build()).active = page < pages - 1;

        // ---- formulario para agregar
        int fy = py + 32;
        if (tab == 0) {
            labelField = field(left, fy, 80, 40, labelText, s -> labelText = s);
            valueField = field(left + 84, fy, 156, 256, valueText, s -> valueText = s);
            countField = null;
            addDrawableChild(ButtonWidget.builder(Text.literal("Añadir"), b -> add())
                    .dimensions(left + 244, fy, 76, 20).build());
        } else {
            labelField = field(left, fy, 64, 40, labelText, s -> labelText = s);
            valueField = field(left + 68, fy, 104, 256, valueText, s -> valueText = s);
            countField = field(left + 176, fy, 30, 3, countText, s -> countText = s);
            addDrawableChild(ButtonWidget.builder(Text.literal("Mano"), b -> fromHand())
                    .dimensions(left + 210, fy, 44, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Añadir"), b -> add())
                    .dimensions(left + 258, fy, 62, 20).build());
        }

        // ---- opciones
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Cerrar al ejecutar: " + (closeOnRun ? "Sí" : "No")), b -> {
                    closeOnRun = !closeOnRun;
                    clearAndInit();
                }).dimensions(left + 60, top + PANEL_H - 22, 200, 20).build());
    }

    private TextFieldWidget field(int x, int y, int w, int max, String text, java.util.function.Consumer<String> onChange) {
        TextFieldWidget f = new TextFieldWidget(this.textRenderer, x, y, w, 20, Text.empty());
        f.setMaxLength(max);
        f.setText(text);
        f.setChangedListener(onChange);
        addDrawableChild(f);
        return f;
    }

    private void run(MenuEntry e) {
        ClientPlayNetworking.send(new RunPayload(e.id));
        if (closeOnRun) close();
    }

    private void remove(MenuEntry e) {
        ClientPlayNetworking.send(new RemovePayload(e.id));
    }

    private void add() {
        String v = valueText.trim();
        if (v.isEmpty()) {
            ClientState.feedback = tab == 0 ? "Escribe un comando" : "Escribe el id del objeto";
            return;
        }
        int count = 1;
        try {
            count = Integer.parseInt(countText.trim());
        } catch (NumberFormatException ignored) {
        }
        ClientPlayNetworking.send(new AddPayload(tab == 0 ? "command" : "item", labelText.trim(), v, count));
        labelText = "";
        valueText = "";
        ClientState.feedback = "";
        clearAndInit();
    }

    /** Toma el objeto de tu mano principal. */
    private void fromHand() {
        if (this.client == null || this.client.player == null) return;
        ItemStack st = this.client.player.getMainHandStack();
        if (st.isEmpty()) {
            ClientState.feedback = "Tienes la mano vacía";
            clearAndInit();
            return;
        }
        valueText = Registries.ITEM.getId(st.getItem()).toString();
        countText = String.valueOf(st.getCount());
        if (labelText.isBlank()) labelText = st.getName().getString();
        ClientState.feedback = "";
        clearAndInit();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean enter = keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER;
        if (enter && ((labelField != null && labelField.isFocused())
                || (valueField != null && valueField.isFocused())
                || (countField != null && countField.isFocused()))) {
            add();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int pages = Math.max(1, (shown.size() + ROWS - 1) / ROWS);
        if (verticalAmount < 0 && page < pages - 1) {
            page++;
            clearAndInit();
            return true;
        }
        if (verticalAmount > 0 && page > 0) {
            page--;
            clearAndInit();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // fondo + botones + campos

        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, top + 4, 0xFFFFFF);

        // ---- filas
        int start = page * ROWS;
        for (int i = 0; i < ROWS && start + i < shown.size(); i++) {
            MenuEntry e = shown.get(start + i);
            int y = top + 42 + i * ROW_H;
            ctx.fill(left, y - 1, left + 232, y + 21, 0x66000000);
            int tx = left + 4;
            if (tab == 1) {
                Identifier id = Identifier.tryParse(e.value);
                if (id != null && Registries.ITEM.containsId(id)) {
                    ctx.drawItem(new ItemStack(Registries.ITEM.get(id)), left + 3, y + 2);
                }
                tx = left + 24;
            }
            int maxW = 232 - (tx - left) - 4;
            ctx.drawText(this.textRenderer, this.textRenderer.trimToWidth(e.label, maxW), tx, y + 2, 0xFFFFFF, false);
            String sub = tab == 0 ? e.value : (e.value + " ×" + e.count);
            ctx.drawText(this.textRenderer, this.textRenderer.trimToWidth(sub, maxW), tx, y + 12, 0xAAAAAA, false);
        }
        if (shown.isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal(tab == 0 ? "No hay comandos todavía. Añade uno abajo." : "No hay objetos todavía. Añade uno abajo."),
                    this.width / 2, top + 42 + 40, 0xAAAAAA);
        }

        // ---- pagina
        int pages = Math.max(1, (shown.size() + ROWS - 1) / ROWS);
        int py = top + 42 + ROWS * ROW_H + 2;
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Pág. " + (page + 1) + "/" + pages),
                this.width / 2, py + 6, 0xFFFFFF);

        // ---- etiquetas del formulario
        int fy = py + 32;
        ctx.drawText(this.textRenderer, "Añadir nuevo:", left, fy - 22, 0xFFFFFF, true);
        ctx.drawText(this.textRenderer, "Nombre", left, fy - 10, 0xAAAAAA, false);
        if (tab == 0) {
            ctx.drawText(this.textRenderer, "Comando (sin /)", left + 84, fy - 10, 0xAAAAAA, false);
        } else {
            ctx.drawText(this.textRenderer, "ID del objeto", left + 68, fy - 10, 0xAAAAAA, false);
            ctx.drawText(this.textRenderer, "Cant.", left + 176, fy - 10, 0xAAAAAA, false);
        }

        // ---- mensaje del servidor
        if (!ClientState.feedback.isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(ClientState.feedback),
                    this.width / 2, fy + 24, 0xFFFF55);
        }
    }
}

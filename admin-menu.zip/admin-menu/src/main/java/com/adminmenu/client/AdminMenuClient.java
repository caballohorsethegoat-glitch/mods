package com.adminmenu.client;

import com.adminmenu.AdminMenuMod;
import com.adminmenu.network.FeedbackPayload;
import com.adminmenu.network.RequestPayload;
import com.adminmenu.network.SyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;

public class AdminMenuClient implements ClientModInitializer {
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        // Tecla "." (se puede cambiar en Opciones > Controles)
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.adminmenu.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_PERIOD, "key.category.adminmenu"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen != null || client.player == null) continue;
                if (client.player.hasPermissionLevel(AdminMenuMod.OP_LEVEL)) {
                    ClientPlayNetworking.send(new RequestPayload());
                    client.setScreen(new AdminMenuScreen());
                } else {
                    client.player.sendMessage(Text.literal("§cSolo los OP pueden abrir el menú de admin."), true);
                }
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ClientState.entries = new ArrayList<>(payload.entries());
                    if (MinecraftClient.getInstance().currentScreen instanceof AdminMenuScreen s) s.refresh();
                }));

        ClientPlayNetworking.registerGlobalReceiver(FeedbackPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    ClientState.feedback = payload.text();
                    if (MinecraftClient.getInstance().currentScreen instanceof AdminMenuScreen s) s.refresh();
                }));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ClientState.entries = new ArrayList<>();
            ClientState.feedback = "";
        });
    }
}

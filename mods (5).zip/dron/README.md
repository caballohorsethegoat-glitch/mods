# Dron - Fabric 1.21.1

- Entidad `dronmod:dron` (huevo generador; `/summon dronmod:dron`). No aparece solo.
- Te persigue siempre y flota a ~3 bloques (al alcance de espada y flecha). Si te alejas mucho (enderpearl, etc.) se teletransporta a ti.
- Dispara bolas de fuego moradas con un sonido de carga previo: queman, dan debilidad y dejan una zona de fuego morado.
- A menos de ~8.5 bloques y con linea de vision te agarra: camara bloqueada, y NO puedes atacar, romper/poner bloques ni usar items (arco, perlas...).
- Pantalla dinamica: viñeta roja que late, tecla ESPACIO animada con onda y chispas, barra con degradado, mensaje que cambia, temblor.
- Al llenar la barra te libera; no puede volver a agarrarte durante ~8 s, pero sigue cerca y disparando (ahi puedes matarlo).
- Al morir explota como un creeper normal. Zumbido de dron cerca y estatica mientras te agarra.

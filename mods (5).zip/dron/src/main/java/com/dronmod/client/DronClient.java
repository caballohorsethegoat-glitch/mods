package com.dronmod.client;

import com.dronmod.DronMod;
import com.dronmod.entity.DroneEntity;
import com.dronmod.network.EscapePayload;
import com.dronmod.network.LockPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class DronClient implements ClientModInitializer {
    private static final float PRESS_GAIN = 0.07f;   // cuanto sube la barra por cada ESPACIO
    private static final float DECAY = 0.004f;       // cuanto baja sola por tick

    // chispas que salen de la tecla al pulsar: {x, y, vx, vy, nacimientoMs}
    private static final List<float[]> sparks = new ArrayList<>();
    private static long lastSparkPress = 0;

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(DronMod.DRON, DroneRenderer::new);
        EntityRendererRegistry.register(DronMod.DRON_FIREBALL, ctx -> new FlyingItemEntityRenderer<>(ctx, 2.0f, true));

        DroneEntity.clientTickHook = drone -> {
            if (!drone.soundStarted) {
                drone.soundStarted = true;
                MinecraftClient.getInstance().getSoundManager().play(new DroneSoundInstance(drone));
            }
        };
        // el cliente le dice a los callbacks de ataque/uso si estas agarrado (cancela al instante)
        DroneEntity.clientLockedHook = () -> DroneClientState.active;

        ClientPlayNetworking.registerGlobalReceiver(LockPayload.ID, (payload, context) ->
                context.client().execute(() -> {
                    if (payload.active()) {
                        boolean was = DroneClientState.active;
                        DroneClientState.start(payload.droneId());
                        if (!was) MinecraftClient.getInstance().getSoundManager().play(new StaticSoundInstance());
                    } else {
                        DroneClientState.stop();
                    }
                }));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> DroneClientState.stop());
        ClientTickEvents.END_CLIENT_TICK.register(DronClient::tickLock);
        HudRenderCallback.EVENT.register(DronClient::renderLockHud);
    }

    private static void tickLock(MinecraftClient client) {
        if (!DroneClientState.active || client.player == null || client.world == null) return;

        Entity drone = client.world.getEntityById(DroneClientState.droneId);
        if (drone == null || !drone.isAlive()) {
            if (++DroneClientState.missingTicks > 40) DroneClientState.stop();
            return;
        }
        DroneClientState.missingTicks = 0;

        // Obliga a mirar al dron
        Vec3d from = client.player.getEyePos();
        Vec3d to = drone.getPos().add(0, drone.getHeight() * 0.5, 0);
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float targetYaw = (float) (-MathHelper.atan2(dx, dz) * 180.0 / Math.PI);
        float targetPitch = (float) (-MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
        client.player.setYaw(client.player.getYaw() + MathHelper.wrapDegrees(targetYaw - client.player.getYaw()) * 0.4f);
        client.player.setPitch(MathHelper.clamp(client.player.getPitch()
                + (targetPitch - client.player.getPitch()) * 0.4f, -90.0f, 90.0f));

        // Cada pulsacion de ESPACIO llena la barra
        while (client.options.jumpKey.wasPressed()) {
            DroneClientState.progress += PRESS_GAIN;
            DroneClientState.lastPressMs = System.currentTimeMillis();
        }
        DroneClientState.progress = Math.max(0f, DroneClientState.progress - DECAY);

        if (DroneClientState.progress >= 1.0f) {
            ClientPlayNetworking.send(new EscapePayload());
            DroneClientState.stop();
        }
    }

    /** Rojo -> amarillo -> verde segun el progreso. */
    private static int barColor(float f) {
        int r, g;
        if (f < 0.5f) {
            r = 255;
            g = (int) (255 * (f / 0.5f));
        } else {
            r = (int) (255 * (1.0f - (f - 0.5f) / 0.5f));
            g = 255;
        }
        return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
    }

    private static void renderLockHud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (!DroneClientState.active) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        int cx = w / 2;

        long now = System.currentTimeMillis();
        float p = Math.max(0f, Math.min(1f, DroneClientState.progress));
        float danger = 1.0f - p;
        long sincePress = now - DroneClientState.lastPressMs;
        float flash = sincePress < 180 ? 1.0f - sincePress / 180.0f : 0.0f;

        // ---- Viñeta roja: late mas rapido y fuerte cuanto menos progreso llevas; se aclara al pulsar
        float pulse = 0.7f + 0.3f * (float) Math.sin(now / (150.0 + 200.0 * p));
        float strength = (0.55f + 0.45f * danger) * pulse * (1.0f - 0.35f * flash);
        int n = (int) (Math.min(w, h) * (0.24f + 0.12f * danger));
        for (int i = 0; i < n; i++) {
            float f = 1.0f - i / (float) n;
            int a = Math.max(0, Math.min(255, (int) (f * f * 190 * strength)));
            int col = (a << 24) | 0xC80000;
            ctx.fill(0, i, w, i + 1, col);            // arriba
            ctx.fill(0, h - 1 - i, w, h - i, col);    // abajo
            ctx.fill(i, 0, i + 1, h, col);            // izquierda
            ctx.fill(w - 1 - i, 0, w - i, h, col);    // derecha
        }

        // ---- Temblor de la interfaz (mas fuerte con peligro y al pulsar)
        Random rnd = new Random(now / 40);
        float amp = danger * 2.5f + flash * 2.0f;
        float shakeX = (rnd.nextFloat() * 2 - 1) * amp;
        float shakeY = (rnd.nextFloat() * 2 - 1) * amp;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(shakeX, shakeY, 0);

        int keyW = 84, keyH = 20;
        int x = cx - keyW / 2;
        int y = h / 2 + 38;

        // la tecla parpadea mas rapido cuanto menos progreso llevas
        long period = (long) (260 + 300 * p);
        boolean down = sincePress < 140 || (now / period) % 2 == 0;
        int off = down ? 3 : 0;

        // ---- Mensaje que cambia con el progreso y "late"
        String msg;
        int msgColor;
        if (p < 0.3f) {
            msg = "¡MACHACA ESPACIO!";
            msgColor = ((now / 200) % 2 == 0) ? 0xFF5555 : 0xFFFF55;
        } else if (p < 0.7f) {
            msg = "¡NO PARES!";
            msgColor = 0xFFAA00;
        } else {
            msg = "¡CASI LIBRE!";
            msgColor = 0x55FF55;
        }
        float scale = 1.35f + 0.1f * (float) Math.sin(now / 120.0) + 0.3f * flash;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(cx, y - 26, 0);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(msg), 0, 0, msgColor);
        ctx.getMatrices().pop();

        // ---- Onda expansiva al pulsar
        if (sincePress < 320) {
            float t = sincePress / 320.0f;
            int grow = (int) (t * 28);
            int al = (int) ((1.0f - t) * 220);
            int rc = (al << 24) | 0xFFFFFF;
            int x1 = x - grow, y1 = y - grow, x2 = x + keyW + grow, y2 = y + keyH + grow;
            ctx.fill(x1, y1, x2, y1 + 2, rc);
            ctx.fill(x1, y2 - 2, x2, y2, rc);
            ctx.fill(x1, y1, x1 + 2, y2, rc);
            ctx.fill(x2 - 2, y1, x2, y2, rc);
        }

        // ---- Tecla ESPACIO (base + tapa que se hunde)
        ctx.fill(x - 1, y + 3, x + keyW + 1, y + keyH + 4, 0xFF111111);
        ctx.fill(x, y + off, x + keyW, y + off + keyH, down ? 0xFFB5B5B5 : 0xFFEAEAEA);
        ctx.fill(x, y + off, x + keyW, y + off + 1, 0xFFFFFFFF);
        ctx.fill(x, y + off + keyH - 1, x + keyW, y + off + keyH, 0xFF8A8A8A);
        Text label = Text.literal("ESPACIO");
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, cx - tw / 2, y + off + 6, 0xFF202020, false);

        // ---- Chispas al pulsar
        if (DroneClientState.lastPressMs != lastSparkPress) {
            lastSparkPress = DroneClientState.lastPressMs;
            for (int i = 0; i < 12; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                float sp = 40 + rnd.nextFloat() * 90;
                sparks.add(new float[]{cx, y + keyH / 2.0f, (float) Math.cos(ang) * sp, (float) Math.sin(ang) * sp - 30, now});
            }
        }
        for (Iterator<float[]> it = sparks.iterator(); it.hasNext(); ) {
            float[] s = it.next();
            float age = (now - s[4]);
            if (age > 600) {
                it.remove();
                continue;
            }
            float sec = age / 1000.0f;
            float sx = s[0] + s[2] * sec;
            float sy = s[1] + s[3] * sec + 120 * sec * sec;
            int a = (int) ((1.0f - age / 600.0f) * 255);
            int size = age < 300 ? 3 : 2;
            ctx.fill((int) sx, (int) sy, (int) sx + size, (int) sy + size, (a << 24) | 0xFFD040);
        }

        // ---- Barra con degradado rojo -> verde, brillo y marcas
        int bw = 140, bh = 10;
        int bx = cx - bw / 2;
        int by = y + keyH + 18;
        int fillW = (int) (bw * p);
        ctx.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, flash > 0.3f ? 0xFFFFFF55 : 0xFFFFFFFF);
        ctx.fill(bx, by, bx + bw, by + bh, 0xFF000000);
        for (int px = 0; px < fillW; px += 2) {
            ctx.fill(bx + px, by, Math.min(bx + px + 2, bx + fillW), by + bh, barColor(px / (float) bw));
        }
        if (fillW > 0) ctx.fill(bx, by, bx + fillW, by + 2, 0x66FFFFFF);          // brillo superior
        if (flash > 0) ctx.fill(bx, by, bx + bw, by + bh, ((int) (flash * 110) << 24) | 0xFFFFFF); // destello al pulsar
        for (int i = 1; i < 4; i++) ctx.fill(bx + bw * i / 4, by, bx + bw * i / 4 + 1, by + bh, 0xAA000000); // marcas 25/50/75 %

        String pct = (int) (p * 100) + "%";
        ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(pct), cx, by + bh + 4, 0xFFFFFF);

        ctx.getMatrices().pop();
    }
}

package com.dronmod;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    public static final SoundEvent DRONE_LOOP = register("drone_loop");
    public static final SoundEvent STATIC_LOOP = register("static_loop");
    public static final SoundEvent DRONE_CHARGE = register("drone_charge");

    private static SoundEvent register(String name) {
        Identifier id = DronMod.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void init() {
        // fuerza la carga de la clase (registro de sonidos)
    }
}

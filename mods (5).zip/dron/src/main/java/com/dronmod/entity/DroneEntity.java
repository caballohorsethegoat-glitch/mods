package com.dronmod.entity;

import com.dronmod.ModSounds;
import com.dronmod.network.LockPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.control.FlightMoveControl;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.FlyGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.pathing.BirdNavigation;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Dron: te persigue siempre (se teletransporta si te alejas mucho), flota cerca de ti
 * (al alcance de espada y flecha), dispara bolas de fuego moradas y te "agarra":
 * el cliente bloquea la camara y no puedes atacar ni usar items hasta llenar la barra de ESPACIO.
 */
public class DroneEntity extends HostileEntity {
    public static final double HOVER_DIST = 3.2;          // distancia a la que flota (alcance de espada)
    public static final double LOCK_DIST = 8.5;           // a esta distancia (con linea de vision) te agarra
    public static final int REGRAB_COOLDOWN = 160;        // ticks sin poder agarrar tras liberarte (8 s)
    public static final double TELEPORT_DIST = 28.0;      // si te alejas mas, se teletransporta a ti
    public static final double GRAB_TELEPORT_DIST = 16.0; // igual, pero mientras te tiene agarrado
    public static final int CHARGE_TICKS = 22;            // tiempo de carga antes de lanzar la bola

    /** Jugadores agarrados (lado servidor). */
    public static final Set<UUID> GRABBED = ConcurrentHashMap.newKeySet();
    /** Lo rellena el cliente: dice si el jugador local esta agarrado. */
    public static BooleanSupplier clientLockedHook = () -> false;
    /** Lo rellena el cliente: inicia el sonido en bucle del dron. */
    public static Consumer<DroneEntity> clientTickHook = e -> {};
    public boolean soundStarted = false;

    private UUID grabbed = null;
    private int cooldown = 0;
    private int shootTimer = 40;
    private int chargeTicks = 0;

    public DroneEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.moveControl = new FlightMoveControl(this, 20, true);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createDroneAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 16.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.7)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    /** True si este jugador esta agarrado por un dron (en cliente usa el estado local). */
    public static boolean isLocked(PlayerEntity p) {
        if (p.getWorld().isClient) return clientLockedHook.getAsBoolean();
        return GRABBED.contains(p.getUuid());
    }

    @Override
    protected EntityNavigation createNavigation(World world) {
        return new BirdNavigation(this, world);
    }

    @Override
    protected void initGoals() {
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        this.goalSelector.add(1, new HoverGoal(this));
        this.goalSelector.add(5, new FlyGoal(this, 1.0));
    }

    @Override
    public boolean isDisallowedInPeaceful() {
        return false;
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isOf(DamageTypes.IN_WALL)) return false; // no se asfixia al teletransportarse
        return super.damage(source, amount);
    }

    public boolean isGrabbing(PlayerEntity p) {
        return grabbed != null && grabbed.equals(p.getUuid());
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) {
            clientTickHook.accept(this);
            return;
        }
        if (cooldown > 0) cooldown--;

        LivingEntity target = getTarget();
        PlayerEntity gp = grabbed == null ? null : getWorld().getPlayerByUuid(grabbed);
        if (gp != null && target != gp) setTarget(gp);
        LivingEntity chase = gp != null ? gp : target;

        if (chase != null) {
            // siempre de frente al jugador
            double dx = chase.getX() - getX();
            double dz = chase.getZ() - getZ();
            float yaw = (float) (-MathHelper.atan2(dx, dz) * 180.0 / Math.PI);
            setYaw(yaw);
            setBodyYaw(yaw);
            setHeadYaw(yaw);

            // si te alejas mucho (enderpearl, etc.) el dron se teletransporta a ti
            double limit = gp != null ? GRAB_TELEPORT_DIST : TELEPORT_DIST;
            if (distanceTo(chase) > limit) teleportNear(chase);
        }

        // ---- ataque a distancia: carga (con sonido) y luego lanza la bola
        if (target != null) {
            if (chargeTicks > 0) {
                chargeTicks--;
                if (getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(DronFireballEntity.PURPLE, getX(), getY() + 0.4, getZ(), 3, 0.35, 0.2, 0.35, 0.02);
                }
                if (chargeTicks == 0) {
                    if (canSee(target) && distanceTo(target) <= 24.0) shootFireball(target);
                    shootTimer = grabbed != null ? 70 : 50;
                }
            } else if (shootTimer > 0) {
                shootTimer--;
            } else if (canSee(target) && distanceTo(target) <= 24.0 && distanceTo(target) >= 1.5) {
                chargeTicks = CHARGE_TICKS;
                getWorld().playSound(null, getX(), getY(), getZ(), ModSounds.DRONE_CHARGE,
                        SoundCategory.HOSTILE, 1.4f, 1.0f);
            }
        }

        // ---- agarre
        if (grabbed != null) {
            if (gp == null || !gp.isAlive() || gp.isSpectator() || gp.getWorld() != getWorld()) {
                releasePlayer(false);
            } else if (age % 20 == 0 && gp instanceof ServerPlayerEntity sp) {
                ServerPlayNetworking.send(sp, new LockPayload(getId(), true)); // refresco
            }
        } else if (cooldown == 0 && target instanceof ServerPlayerEntity sp && sp.isAlive()
                && distanceTo(sp) <= LOCK_DIST && canSee(sp) && !GRABBED.contains(sp.getUuid())) {
            grabbed = sp.getUuid();
            GRABBED.add(grabbed);
            sp.stopUsingItem(); // cancela arco, escudo, etc.
            ServerPlayNetworking.send(sp, new LockPayload(getId(), true));
        }
    }

    private void teleportNear(LivingEntity t) {
        for (int i = 0; i < 10; i++) {
            double ang = random.nextDouble() * Math.PI * 2;
            double r = i < 6 ? HOVER_DIST : 1.5;
            double x = t.getX() + Math.cos(ang) * r;
            double z = t.getZ() + Math.sin(ang) * r;
            double y = t.getEyeY() + (i < 6 ? 0.0 : 1.0);
            Box moved = getBoundingBox().offset(x - getX(), y - getY(), z - getZ());
            if (getWorld().isSpaceEmpty(this, moved) || i == 9) {
                getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                        SoundCategory.HOSTILE, 1.0f, 1.6f);
                refreshPositionAndAngles(x, y, z, getYaw(), getPitch());
                getNavigation().stop();
                setVelocity(Vec3d.ZERO);
                getWorld().playSound(null, x, y, z, SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                        SoundCategory.HOSTILE, 1.0f, 1.6f);
                return;
            }
        }
    }

    private void shootFireball(LivingEntity target) {
        World w = getWorld();
        DronFireballEntity ball = new DronFireballEntity(w, this);
        Vec3d from = new Vec3d(getX(), getY() + 0.35, getZ());
        Vec3d dir = target.getEyePos().subtract(from).normalize();
        ball.setPosition(from.x + dir.x * 0.9, from.y + dir.y * 0.9, from.z + dir.z * 0.9);
        ball.setVelocity(dir.x, dir.y, dir.z, 1.1f, 0.0f);
        w.spawnEntity(ball);
        w.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.HOSTILE, 1.0f, 0.6f);
    }

    /** Explota como un creeper normal al morir. */
    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);
        if (!getWorld().isClient) {
            releasePlayer(false);
            getWorld().createExplosion(this, getX(), getY(), getZ(), 3.0f, World.ExplosionSourceType.MOB);
        }
    }

    /** Suelta al jugador. Si escaped=true no puede volver a agarrarlo durante un rato (pero sigue cerca y disparando). */
    public void releasePlayer(boolean escaped) {
        if (grabbed != null) {
            GRABBED.remove(grabbed);
            PlayerEntity p = getWorld().getPlayerByUuid(grabbed);
            if (p instanceof ServerPlayerEntity sp) {
                ServerPlayNetworking.send(sp, new LockPayload(getId(), false));
            }
            grabbed = null;
        }
        if (escaped) cooldown = REGRAB_COOLDOWN;
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!getWorld().isClient) releasePlayer(false);
        super.remove(reason);
    }

    /** Persigue al jugador y flota a HOVER_DIST con un ligero vaiven (se puede golpear con habilidad). */
    private static class HoverGoal extends Goal {
        private final DroneEntity drone;

        HoverGoal(DroneEntity drone) {
            this.drone = drone;
            setControls(EnumSet.of(Control.MOVE, Control.LOOK));
        }

        @Override
        public boolean canStart() {
            LivingEntity t = drone.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean shouldContinue() {
            return canStart();
        }

        @Override
        public void tick() {
            LivingEntity t = drone.getTarget();
            if (t == null) return;
            Vec3d eye = t.getEyePos();
            Vec3d flat = new Vec3d(drone.getX() - eye.x, 0, drone.getZ() - eye.z);
            flat = flat.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : flat.normalize();
            Vec3d side = new Vec3d(-flat.z, 0, flat.x);
            double sway = Math.sin(drone.age * 0.12) * 1.1;
            double bob = Math.sin(drone.age * 0.2) * 0.25;
            Vec3d want = eye.add(flat.multiply(HOVER_DIST)).add(side.multiply(sway)).add(0, 0.1 + bob, 0);
            if (drone.squaredDistanceTo(want) > 0.25) {
                drone.getMoveControl().moveTo(want.x, want.y, want.z, 1.5);
            }
            drone.getLookControl().lookAt(t, 30.0f, 30.0f);
        }
    }
}
